//Chirila DB Javascript File
//By Abhi Nayar, Yale 2018
//Computing & the Arts and Economics

//For inquiries please email anayar2[at]gmail[dot]com
/*
Dependencies:
-jQuery
-Papa Parse
-Persist JS
*/

//Global Vars.
var _store; //PersistJS object
var _global_data; //CSV -> JSON converted object (will be cached in storage via Persist). Too large so need alt. solution.

$.noConflict;
$(document).on('ready', function(){
  //We're going to spoof live CSV loads using Firebase as a temporary solution
  //Eventually we want to optimize so we can load directly into memory but that optimization is proving horrendous.
  
  /* Get Firebase DB's */
  var db0 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFRdfuc4nfxI6a-eR/db0');
  var db1 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFUHLM6zkNaPGpF1Y/db1');
  var db2 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFXd0ssw8y7DCx3S7/db2');
  var db3 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvF_5OYWIEEGKG5ppd/db3');

  //define sub global vars.
  var globalData,
      data0, data1, data2, data3;
  
  //Firebase functions to get the values
  //Firebase db's are split because the size was too big for a single firebase sub db
  db0.on("value", function(snapshot){
    data0 = snapshot.val();
  });
  db1.on("value", function(snapshot){
    data1 = snapshot.val();
  });
  db2.on("value", function(snapshot){
    data2 = snapshot.val();
  });
  db3.on("value", function(snapshot){
    data3 = snapshot.val();
    //Concatenate all the pieces together
    concatData();
  });
  
  //concatenates all the data together.
  //start DOING things after this function
  function concatData(){
    globalData = data0.concat(data1, data2, data3);
    //Remove loader
    //TODO
    createGlobalDataStore();
  };
  
  
});

