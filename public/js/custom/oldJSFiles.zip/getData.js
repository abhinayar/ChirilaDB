//Chirila DB Javascript File
//By Abhi Nayar, Yale 2018
//Computing & the Arts and Economics

//For inquiries please email anayar2[at]gmail[dot]com
/*
Dependencies:
-jQuery
-Papa Parse
-Persist JS //Not in current version as file sizes exceed limits
*/

/* 
Version 0.1 Notes:
The current system works by querying a Firebase database and parsing the resulting JSON into one big dataset.
This is by no means the best, most efficient or even smart way of doing things- it just works.
Since this is structured data the best bet might be a MySQL datatable and a RAILS app, but in the meantime (till v1) this will have to do.
TODO: Change the way data storage is implemented
TODO: Figure out PersistJS alternative to storing data locally without exceeding localStorage limits
*/

function getData() {
  var globaldata = null; //global data container
 
  //We're going to spoof live CSV loads using Firebase as a temporary solution
  //Eventually we want to optimize so we can load directly into memory but that optimization is proving horrendous.
  
  /* Get Firebase DB's */
  var db0 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFRdfuc4nfxI6a-eR/db0');
  var db1 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFUHLM6zkNaPGpF1Y/db1');
  var db2 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvFXd0ssw8y7DCx3S7/db2');
  var db3 = new Firebase('https://chiriladb-1487143035648.firebaseio.com/-KhvF_5OYWIEEGKG5ppd/db3');

  //define sub global vars.
  var data0, data1, data2, data3;
  
  //Firebase functions to get the values
  //Firebase db's are split because the size was too big for a single firebase sub db
  db0.on("value", function(snapshot){
    data0 = snapshot.val();
  });
  db1.on("value", function(snapshot){
    data1 = snapshot.val();
  });
  db2.on("value", function(snapshot){
    data2 = snapshot.val();
  });
  db3.on("value", function(snapshot){
    data3 = snapshot.val();
    //Concatenate all the pieces together and return
    //This function ostensibly runs last so this code is placed here... may lead to errors (WATCH THIS!)
    globaldata = concatData();
    //return the global
    return globaldata;
  });
  
  //concatenates all the data together.
  //start DOING things after this function
  function concatData(){
    return data0.concat(data1, data2, data3);
    //Remove loader
    //TODO
  };  
});

